# def relation_to_luke(v):
#     mydict = {
#         "Darth Vader": "Luke, I am your father.",
#         "Leila": "Luke, I am your sister.",
#         "han": "Luke, I am brother in law."
#     }
#     return mydict[v]

# print(relation_to_luke("Leila"))

# def get_student_names(names):
#     return sorted(names.values())